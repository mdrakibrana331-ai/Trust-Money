import { randomBytes, randomInt } from "node:crypto";
import type { Request, Response } from "express";
import { and, desc, eq } from "drizzle-orm";
import { getAuth } from "@clerk/express";
import {
  db,
  spinResultsTable,
  tasksTable,
  usersTable,
  type User,
} from "@workspace/db";

function isUniqueViolation(error: unknown): boolean {
  if (!error || typeof error !== "object") return false;
  const candidate = error as { code?: string; cause?: { code?: string } };
  return candidate.code === "23505" || candidate.cause?.code === "23505";
}

export async function getAuthenticatedUser(
  req: Request,
  res: Response,
): Promise<User | null> {
  const auth = getAuth(req);
  const clerkUserId = auth?.userId;
  if (!clerkUserId) {
    res.status(401).json({ error: "Sign in to use this feature." });
    return null;
  }

  const existing = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.clerkUserId, clerkUserId))
    .limit(1);
  if (existing[0]) return existing[0];

  const referralCode = `TM-${randomBytes(4).toString("hex").toUpperCase()}`;
  try {
    const [created] = await db
      .insert(usersTable)
      .values({ clerkUserId, referralCode })
      .returning();
    if (created) return created;
  } catch (error) {
    // Concurrent first requests can collide on the Clerk user unique index.
    // Only recover that expected race; surface unrelated database failures.
    if (!isUniqueViolation(error)) throw error;
  }

  // A newly created Clerk session can make two API requests at once. If the
  // unique user insert lost a race, read the row created by the other request
  // instead of returning undefined to route handlers.
  const [createdByAnotherRequest] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.clerkUserId, clerkUserId))
    .limit(1);
  if (createdByAnotherRequest) return createdByAnotherRequest;

  res.status(500).json({ error: "Your account could not be initialized. Please try again." });
  return null;
}

export async function ensureTaskCatalog(): Promise<void> {
  const existing = await db.select({ id: tasksTable.id }).from(tasksTable).limit(1);
  if (existing.length > 0) return;

  await db.insert(tasksTable).values([
    {
      title: "Tell us what matters to you",
      category: "Survey",
      description: "A short product feedback demo with no cash value.",
      duration: "5–7 min",
    },
    {
      title: "Explore a featured service",
      category: "Offer",
      description: "Review a sample offer flow in a safe demo environment.",
      duration: "A few minutes",
    },
    {
      title: "Complete your Trust Money profile",
      category: "Profile",
      description: "Add the details you want to keep on your account.",
      duration: "1–2 min",
    },
  ]);
}

export function today(): string {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Dhaka",
  }).format(new Date());
}

export function toIso(value: Date | null | undefined): string | null {
  if (!(value instanceof Date) || Number.isNaN(value.getTime())) return null;
  return value.toISOString();
}

export function pickDemoSpin(): { label: string; demoCredits: number } {
  const outcomes = [
    { label: "5 demo credits", demoCredits: 5 },
    { label: "Try again tomorrow", demoCredits: 0 },
    { label: "10 demo credits", demoCredits: 10 },
  ];
  return outcomes[randomInt(0, outcomes.length)];
}

export async function getLatestSpin(userId: number) {
  const latest = await db
    .select()
    .from(spinResultsTable)
    .where(eq(spinResultsTable.userId, userId))
    .orderBy(desc(spinResultsTable.spunAt))
    .limit(1);
  return latest[0] ?? null;
}

export function getHostLink(req: Request, referralCode: string): string {
  const forwardedProto = req.headers["x-forwarded-proto"];
  const protocol = (Array.isArray(forwardedProto) ? forwardedProto[0] : forwardedProto) ?? "http";
  const host = req.headers.host ?? "trust-money.local";
  return `${protocol}://${host}/sign-up?ref=${referralCode}`;
}

export function maskAccountNumber(accountNumber: string): string {
  if (!accountNumber) return "Not provided";
  if (accountNumber.length <= 4) return accountNumber;
  return `${"•".repeat(Math.max(0, accountNumber.length - 4))}${accountNumber.slice(-4)}`;
}