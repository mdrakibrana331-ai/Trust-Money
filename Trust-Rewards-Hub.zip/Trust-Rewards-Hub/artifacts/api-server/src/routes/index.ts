import { Router, type IRouter } from "express";
import healthRouter from "./health";
import rewardsRouter from "./rewards";

const router: IRouter = Router();

router.use(healthRouter);
router.use(rewardsRouter);

export default router;
