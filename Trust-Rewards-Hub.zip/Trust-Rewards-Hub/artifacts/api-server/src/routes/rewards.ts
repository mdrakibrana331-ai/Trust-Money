import { Router, type IRouter } from "express";
import { and, desc, eq, sql } from "drizzle-orm";
import {
  ClaimDailyBonusResponse,
  CompleteTaskParams,
  CompleteTaskResponse,
  CreateWithdrawalBody,
  CreateWithdrawalResponse,
  GetDailyBonusResponse,
  GetLuckySpinResponse,
  GetMeResponse,
  GetReferralResponse,
  GetWalletResponse,
  ListTasksResponse,
  ListTransactionsResponse,
  ListWithdrawalsResponse,
  SpinLuckyWheelResponse,
  UpdateMeBody,
  UpdateMeResponse,
} from "@workspace/api-zod";
import {
  db,
  dailyBonusClaimsTable,
  spinResultsTable,
  taskCompletionsTable,
  tasksTable,
  transactionsTable,
  usersTable,
  withdrawalsTable,
} from "@workspace/db";
import {
  ensureTaskCatalog,
  getAuthenticatedUser,
  getHostLink,
  getLatestSpin,
  maskAccountNumber,
  pickDemoSpin,
  today,
  toIso,
} from "../lib/rewards";

const router: IRouter = Router();

function profileResponse(user: typeof usersTable.$inferSelect) {
  return GetMeResponse.parse({
    id: user.id,
    displayName: user.displayName,
    email: user.email,
    phone: user.phone,
    referralCode: user.referralCode,
    demoCredits: user.demoCredits,
    createdAt: user.createdAt.toISOString(),
  });
}

router.get("/me", async (req, res): Promise<void> => {
  const user = await getAuthenticatedUser(req, res);
  if (!user) return;
  res.json(profileResponse(user));
});

router.patch("/me", async (req, res): Promise<void> => {
  const user = await getAuthenticatedUser(req, res);
  if (!user) return;
  const parsed = UpdateMeBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [updated] = await db
    .update(usersTable)
    .set({ ...parsed.data, updatedAt: new Date() })
    .where(eq(usersTable.id, user.id))
    .returning();
  if (!updated) {
    res.status(404).json({ error: "Profile not found." });
    return;
  }
  res.json(UpdateMeResponse.parse(profileResponse(updated)));
});

router.get("/tasks", async (req, res): Promise<void> => {
  const user = await getAuthenticatedUser(req, res);
  if (!user) return;
  await ensureTaskCatalog();
  const tasks = await db.select().from(tasksTable).where(eq(tasksTable.active, true));
  const completions = await db
    .select()
    .from(taskCompletionsTable)
    .where(eq(taskCompletionsTable.userId, user.id));
  const completedByTask = new Map(completions.map((item) => [item.taskId, item]));
  res.json(ListTasksResponse.parse(tasks.map((task) => ({
    id: task.id,
    title: task.title,
    category: task.category,
    description: task.description,
    duration: task.duration,
    demoOnly: task.demoOnly,
    completed: completedByTask.has(task.id),
    completedAt: toIso(completedByTask.get(task.id)?.completedAt ?? null),
  }))));
});

router.post("/tasks/:id/complete", async (req, res): Promise<void> => {
  const user = await getAuthenticatedUser(req, res);
  if (!user) return;
  const params = CompleteTaskParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  await ensureTaskCatalog();
  const [task] = await db.select().from(tasksTable).where(eq(tasksTable.id, params.data.id)).limit(1);
  if (!task) {
    res.status(404).json({ error: "Task not found." });
    return;
  }
  const [completion] = await db
    .insert(taskCompletionsTable)
    .values({ userId: user.id, taskId: task.id })
    .onConflictDoNothing()
    .returning();
  const existing = completion ?? (await db
    .select()
    .from(taskCompletionsTable)
    .where(and(eq(taskCompletionsTable.userId, user.id), eq(taskCompletionsTable.taskId, task.id)))
    .limit(1))[0];
  res.json(CompleteTaskResponse.parse({
    id: task.id,
    title: task.title,
    category: task.category,
    description: task.description,
    duration: task.duration,
    demoOnly: task.demoOnly,
    completed: true,
    completedAt: toIso(existing?.completedAt ?? new Date()),
  }));
});

router.get("/daily-bonus", async (req, res): Promise<void> => {
  const user = await getAuthenticatedUser(req, res);
  if (!user) return;
  const claimDate = today();
  const [claim] = await db
    .select()
    .from(dailyBonusClaimsTable)
    .where(and(eq(dailyBonusClaimsTable.userId, user.id), eq(dailyBonusClaimsTable.claimDate, claimDate)))
    .limit(1);
  res.json(GetDailyBonusResponse.parse({
    claimDate,
    claimed: Boolean(claim),
    demoOnly: true,
    message: claim ? "Today's demo check-in is already recorded." : "Claiming records a demo check-in only. It has no cash value.",
  }));
});

router.post("/daily-bonus/claim", async (req, res): Promise<void> => {
  const user = await getAuthenticatedUser(req, res);
  if (!user) return;
  const claimDate = today();
  await db.transaction(async (tx) => {
    const [claim] = await tx
      .insert(dailyBonusClaimsTable)
      .values({ userId: user.id, claimDate })
      .onConflictDoNothing()
      .returning();
    if (claim) {
      await tx.insert(transactionsTable).values({
        userId: user.id,
        kind: "daily_bonus",
        label: "Daily bonus check-in recorded",
        demoCredits: 0,
        status: "demo_recorded",
      });
    }
  });
  res.json(ClaimDailyBonusResponse.parse({
    claimDate,
    claimed: true,
    demoOnly: true,
    message: "Today's demo check-in is recorded. No cash value was added.",
  }));
});

router.get("/lucky-spin", async (req, res): Promise<void> => {
  const user = await getAuthenticatedUser(req, res);
  if (!user) return;
  const latest = await getLatestSpin(user.id);
  const isToday = latest ? new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Dhaka" }).format(latest.spunAt) === today() : false;
  res.json(GetLuckySpinResponse.parse({
    available: !isToday,
    demoOnly: true,
    lastSpunAt: toIso(latest?.spunAt ?? null),
  }));
});

router.post("/lucky-spin/spin", async (req, res): Promise<void> => {
  const user = await getAuthenticatedUser(req, res);
  if (!user) return;
  const spinDate = today();
  const existingToday = await db
    .select({ id: spinResultsTable.id })
    .from(spinResultsTable)
    .where(and(eq(spinResultsTable.userId, user.id), eq(spinResultsTable.spinDate, spinDate)))
    .limit(1);
  if (existingToday.length > 0) {
    res.status(409).json({ error: "Your demo spin is already used for today." });
    return;
  }
  const result = pickDemoSpin();
  const spin = await db.transaction(async (tx) => {
    const [createdSpin] = await tx.insert(spinResultsTable).values({
      userId: user.id,
      spinDate,
      label: result.label,
      demoCredits: result.demoCredits,
    }).onConflictDoNothing().returning();
    if (!createdSpin) return null;
    if (result.demoCredits > 0) {
      await tx.update(usersTable).set({
        demoCredits: sql`${usersTable.demoCredits} + ${result.demoCredits}`,
        updatedAt: new Date(),
      }).where(eq(usersTable.id, user.id));
    }
    await tx.insert(transactionsTable).values({
      userId: user.id,
      kind: "lucky_spin",
      label: result.label,
      demoCredits: result.demoCredits,
      status: "demo_recorded",
    });
    return createdSpin;
  });
  if (!spin) {
    res.status(409).json({ error: "Your demo spin is already used for today." });
    return;
  }
  const nextAvailableAt = new Date(spin.spunAt.getTime() + 24 * 60 * 60 * 1000);
  res.json(SpinLuckyWheelResponse.parse({
    label: result.label,
    demoCredits: result.demoCredits,
    demoOnly: true,
    spunAt: spin.spunAt.toISOString(),
    nextAvailableAt: nextAvailableAt.toISOString(),
  }));
});

router.get("/referral", async (req, res): Promise<void> => {
  const user = await getAuthenticatedUser(req, res);
  if (!user) return;
  res.json(GetReferralResponse.parse({
    code: user.referralCode,
    link: getHostLink(req, user.referralCode),
    demoOnly: true,
    referredCount: 0,
  }));
});

router.get("/wallet", async (req, res): Promise<void> => {
  const user = await getAuthenticatedUser(req, res);
  if (!user) return;
  res.json(GetWalletResponse.parse({
    demoCredits: user.demoCredits,
    demoOnly: true,
    label: "Demo credits — no cash value",
  }));
});

router.get("/transactions", async (req, res): Promise<void> => {
  const user = await getAuthenticatedUser(req, res);
  if (!user) return;
  const rows = await db.select().from(transactionsTable)
    .where(eq(transactionsTable.userId, user.id))
    .orderBy(desc(transactionsTable.createdAt));
  res.json(ListTransactionsResponse.parse(rows.map((row) => ({
    id: row.id,
    kind: row.kind,
    label: row.label,
    demoCredits: row.demoCredits,
    status: row.status,
    demoOnly: row.demoOnly,
    createdAt: row.createdAt.toISOString(),
  }))));
});

router.get("/withdrawals", async (req, res): Promise<void> => {
  const user = await getAuthenticatedUser(req, res);
  if (!user) return;
  const rows = await db.select().from(withdrawalsTable)
    .where(eq(withdrawalsTable.userId, user.id))
    .orderBy(desc(withdrawalsTable.createdAt));
  res.json(ListWithdrawalsResponse.parse(rows.map((row) => ({
    id: row.id,
    method: row.method,
    accountNumber: maskAccountNumber(row.accountNumber),
    amountCredits: row.amountCredits,
    status: row.status,
    demoOnly: row.demoOnly,
    note: row.note,
    createdAt: row.createdAt.toISOString(),
  }))));
});

router.post("/withdrawals", async (req, res): Promise<void> => {
  const user = await getAuthenticatedUser(req, res);
  if (!user) return;
  const idempotencyKey = req.get("Idempotency-Key")?.trim();
  if (!idempotencyKey || idempotencyKey.length < 16 || idempotencyKey.length > 128) {
    res.status(400).json({ error: "A valid Idempotency-Key is required for demo withdrawal requests." });
    return;
  }
  const parsed = CreateWithdrawalBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const existing = await db
    .select()
    .from(withdrawalsTable)
    .where(and(eq(withdrawalsTable.userId, user.id), eq(withdrawalsTable.idempotencyKey, idempotencyKey)))
    .limit(1);
  if (existing[0]) {
    res.status(200).json(CreateWithdrawalResponse.parse({
      id: existing[0].id,
      method: existing[0].method,
      accountNumber: maskAccountNumber(existing[0].accountNumber),
      amountCredits: existing[0].amountCredits,
      status: existing[0].status,
      demoOnly: existing[0].demoOnly,
      note: existing[0].note,
      createdAt: existing[0].createdAt.toISOString(),
    }));
    return;
  }
  const withdrawal = await db.transaction(async (tx) => {
    const [createdWithdrawal] = await tx.insert(withdrawalsTable).values({
      userId: user.id,
      idempotencyKey,
      ...parsed.data,
    }).onConflictDoNothing().returning();
    if (!createdWithdrawal) return null;
    await tx.insert(transactionsTable).values({
      userId: user.id,
      kind: "withdrawal",
      label: `Demo withdrawal request via ${parsed.data.method}`,
      demoCredits: 0,
      status: "pending_demo",
    });
    return createdWithdrawal;
  });
  if (!withdrawal) {
    const [existingAfterRace] = await db
      .select()
      .from(withdrawalsTable)
      .where(and(eq(withdrawalsTable.userId, user.id), eq(withdrawalsTable.idempotencyKey, idempotencyKey)))
      .limit(1);
    if (!existingAfterRace) {
      res.status(409).json({ error: "This demo withdrawal request could not be safely created. Try again." });
      return;
    }
    res.status(200).json(CreateWithdrawalResponse.parse({
      id: existingAfterRace.id,
      method: existingAfterRace.method,
      accountNumber: maskAccountNumber(existingAfterRace.accountNumber),
      amountCredits: existingAfterRace.amountCredits,
      status: existingAfterRace.status,
      demoOnly: existingAfterRace.demoOnly,
      note: existingAfterRace.note,
      createdAt: existingAfterRace.createdAt.toISOString(),
    }));
    return;
  }
  res.status(201).json(CreateWithdrawalResponse.parse({
    id: withdrawal.id,
    method: withdrawal.method,
    accountNumber: maskAccountNumber(withdrawal.accountNumber),
    amountCredits: withdrawal.amountCredits,
    status: withdrawal.status,
    demoOnly: withdrawal.demoOnly,
    note: withdrawal.note,
    createdAt: withdrawal.createdAt.toISOString(),
  }));
});

export default router;