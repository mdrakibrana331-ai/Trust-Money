import type { NextFunction, Request, Response } from "express";
import { getAuth } from "@clerk/express";

type Bucket = { count: number; resetAt: number };

const buckets = new Map<string, Bucket>();

function requestSubject(req: Request): string {
  const userId = getAuth(req)?.userId;
  return userId ? `user:${userId}` : `ip:${req.ip ?? req.socket.remoteAddress ?? "unknown"}`;
}

export function apiRateLimit(
  req: Request,
  res: Response,
  next: NextFunction,
): void {
  const now = Date.now();
  const key = `${requestSubject(req)}:${req.method}`;
  const current = buckets.get(key);
  const bucket = !current || current.resetAt <= now
    ? { count: 0, resetAt: now + 60_000 }
    : current;

  bucket.count += 1;
  buckets.set(key, bucket);

  if (buckets.size > 10_000) {
    for (const [bucketKey, value] of buckets) {
      if (value.resetAt <= now) buckets.delete(bucketKey);
    }
  }

  if (bucket.count > 120) {
    res.setHeader("Retry-After", Math.ceil((bucket.resetAt - now) / 1000));
    res.status(429).json({ error: "Too many requests. Please try again shortly." });
    return;
  }

  next();
}