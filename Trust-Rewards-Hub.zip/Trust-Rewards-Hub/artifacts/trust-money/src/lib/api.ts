import type {
  DailyBonus,
  LuckySpinStatus,
  ProfileUpdate,
  Referral,
  SpinResult,
  Task,
  Transaction,
  UserProfile,
  Wallet,
  Withdrawal,
  WithdrawalInput,
} from "@workspace/api-client-react";

async function apiRequest<T>(path: string, init: RequestInit = {}): Promise<T> {
  const headers = new Headers(init.headers);
  if (init.body && !headers.has("Content-Type")) {
    headers.set("Content-Type", "application/json");
  }
  const response = await fetch(`/api${path}`, {
    ...init,
    credentials: "include",
    headers,
  });
  if (!response.ok) {
    const payload = (await response.json().catch(() => null)) as { error?: string } | null;
    throw new Error(payload?.error ?? "Something went wrong. Please try again.");
  }
  return response.json() as Promise<T>;
}

export const rewardsApi = {
  getMe: () => apiRequest<UserProfile>("/me"),
  updateMe: (data: ProfileUpdate) =>
    apiRequest<UserProfile>("/me", { method: "PATCH", body: JSON.stringify(data) }),
  getTasks: () => apiRequest<Task[]>("/tasks"),
  completeTask: (id: number) =>
    apiRequest<Task>(`/tasks/${id}/complete`, { method: "POST" }),
  getDailyBonus: () => apiRequest<DailyBonus>("/daily-bonus"),
  claimDailyBonus: () =>
    apiRequest<DailyBonus>("/daily-bonus/claim", { method: "POST" }),
  getLuckySpin: () => apiRequest<LuckySpinStatus>("/lucky-spin"),
  spinLuckyWheel: () =>
    apiRequest<SpinResult>("/lucky-spin/spin", { method: "POST" }),
  getReferral: () => apiRequest<Referral>("/referral"),
  getWallet: () => apiRequest<Wallet>("/wallet"),
  getTransactions: () => apiRequest<Transaction[]>("/transactions"),
  getWithdrawals: () => apiRequest<Withdrawal[]>("/withdrawals"),
  createWithdrawal: (data: WithdrawalInput, idempotencyKey = crypto.randomUUID()) =>
    apiRequest<Withdrawal>("/withdrawals", {
      method: "POST",
      body: JSON.stringify(data),
      headers: { "Idempotency-Key": idempotencyKey },
    }),
};