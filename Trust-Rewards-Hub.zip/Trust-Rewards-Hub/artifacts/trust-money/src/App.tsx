import { type ReactElement, type ReactNode, useEffect, useMemo, useRef, useState } from "react";
import { QueryClient, QueryClientProvider, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  ArrowRight,
  BadgeCheck,
  Bell,
  Check,
  ChevronRight,
  CircleHelp,
  ClipboardCheck,
  Clock3,
  Copy,
  Gift,
  History,
  House,
  Info,
  LayoutGrid,
  LifeBuoy,
  LoaderCircle,
  LockKeyhole,
  LogOut,
  Pencil,
  RotateCw,
  Search,
  ShieldCheck,
  Sparkles,
  TicketCheck,
  UserRound,
  UsersRound,
  WalletCards,
} from "lucide-react";
import { ClerkProvider, SignIn, SignUp, useAuth, useClerk, useUser } from "@clerk/react";
import { publishableKeyFromHost } from "@clerk/react/internal";
import { shadcn } from "@clerk/themes";
import { Link, Redirect, Route, Switch, Router as WouterRouter, useLocation } from "wouter";
import { ErrorBoundary } from "@/components/error-boundary";
import { Toaster } from "@/components/ui/toaster";
import type {
  DailyBonus,
  LuckySpinStatus,
  Referral,
  SpinResult,
  Task,
  Transaction,
  UserProfile,
  Wallet,
  Withdrawal,
  WithdrawalInput,
} from "@workspace/api-client-react";
import { rewardsApi } from "@/lib/api";
import NotFound from "@/pages/not-found";

const queryClient = new QueryClient({
  defaultOptions: { queries: { staleTime: 20_000, retry: 1 } },
});
const clerkPubKey = publishableKeyFromHost(
  window.location.hostname,
  import.meta.env.VITE_CLERK_PUBLISHABLE_KEY,
);
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;
const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");

type NavEntry = { href: string; label: string; icon: typeof House };

const navItems: NavEntry[] = [
  { href: "/", label: "Overview", icon: House },
  { href: "/tasks", label: "Browse tasks", icon: ClipboardCheck },
  { href: "/daily-bonus", label: "Daily bonus", icon: Gift },
  { href: "/lucky-spin", label: "Lucky spin", icon: RotateCw },
  { href: "/referral", label: "Referral", icon: UsersRound },
];
const accountItems: NavEntry[] = [
  { href: "/wallet", label: "Wallet", icon: WalletCards },
  { href: "/withdrawal", label: "Withdrawal", icon: ArrowRight },
  { href: "/transactions", label: "Transactions", icon: History },
  { href: "/profile", label: "Profile", icon: UserRound },
];
const pageMeta: Record<string, { kicker: string; title: string }> = {
  "/": { kicker: "Trust Money / Overview", title: "Your rewards companion" },
  "/tasks": { kicker: "Discover / Tasks", title: "Browse available tasks" },
  "/daily-bonus": { kicker: "Discover / Daily bonus", title: "A small reason to return" },
  "/lucky-spin": { kicker: "Discover / Lucky spin", title: "Take a thoughtful chance" },
  "/referral": { kicker: "Discover / Referral", title: "Share what feels useful" },
  "/wallet": { kicker: "Account / Wallet", title: "A clear view of your wallet" },
  "/withdrawal": { kicker: "Account / Withdrawal", title: "Move rewards when ready" },
  "/transactions": { kicker: "Account / Transactions", title: "Your activity, in one place" },
  "/profile": { kicker: "Account / Profile", title: "Your account settings" },
};

const appearance = {
  theme: shadcn,
  cssLayerName: "clerk",
  options: {
    logoPlacement: "inside" as const,
    logoLinkUrl: basePath || "/",
    logoImageUrl: `${window.location.origin}${basePath}/logo.svg`,
  },
  variables: {
    colorPrimary: "#0878c9",
    colorForeground: "#1d2b3a",
    colorMutedForeground: "#6a7b89",
    colorDanger: "#c63c3c",
    colorBackground: "#ffffff",
    colorInput: "#f7fafc",
    colorInputForeground: "#1d2b3a",
    colorNeutral: "#d9e4ea",
    fontFamily: "Manrope, sans-serif",
    borderRadius: "0.75rem",
  },
  elements: {
    rootBox: "w-full flex justify-center",
    cardBox: "bg-white rounded-2xl w-[440px] max-w-full overflow-hidden",
    card: "!shadow-none !border-0 !bg-transparent !rounded-none",
    footer: "!shadow-none !border-0 !bg-transparent !rounded-none",
    headerTitle: "text-[#1d2b3a] font-extrabold",
    headerSubtitle: "text-[#6a7b89]",
    socialButtonsBlockButtonText: "text-[#1d2b3a]",
    formFieldLabel: "text-[#1d2b3a]",
    footerActionLink: "text-[#0878c9] font-bold",
    footerActionText: "text-[#6a7b89]",
    dividerText: "text-[#6a7b89]",
    identityPreviewEditButton: "text-[#0878c9]",
    formFieldSuccessText: "text-[#287d5d]",
    alertText: "text-[#c63c3c]",
    logoBox: "mb-4",
    logoImage: "rounded-xl",
    socialButtonsBlockButton: "border-[#d9e4ea] bg-white",
    formButtonPrimary: "bg-[#0878c9] hover:bg-[#066bab]",
    formFieldInput: "border-[#d9e4ea] bg-[#f7fafc] text-[#1d2b3a]",
    footerAction: "bg-transparent",
    dividerLine: "bg-[#d9e4ea]",
    alert: "border-[#f2d0d0] bg-[#fff5f5]",
    otpCodeFieldInput: "border-[#d9e4ea]",
    formFieldRow: "gap-2",
    main: "px-4",
  },
};

function stripBase(path: string): string {
  return basePath && path.startsWith(basePath)
    ? path.slice(basePath.length) || "/"
    : path;
}

function useProfileQuery(enabled = true) {
  return useQuery<UserProfile>({
    queryKey: ["me"],
    queryFn: rewardsApi.getMe,
    enabled,
  });
}

function initials(profile?: UserProfile) {
  if (!profile?.displayName) return "TM";
  return profile.displayName
    .split(/\s+/)
    .filter(Boolean)
    .map((part) => part[0] ?? "")
    .join("")
    .slice(0, 2)
    .toUpperCase();
}

function formatActivityDate(value: unknown): string {
  if (!value) return "Date unavailable";
  const date = value instanceof Date ? value : new Date(String(value));
  return Number.isNaN(date.getTime()) ? "Date unavailable" : date.toLocaleString();
}

function formatTransactionStatus(value: unknown): string {
  return typeof value === "string" && value.trim()
    ? value.replaceAll("_", " ")
    : "recorded";
}

function NavItem({ item, mobile = false }: { item: NavEntry; mobile?: boolean }) {
  const [location] = useLocation();
  const active = item.href === "/" ? location === "/" : location.startsWith(item.href);
  return (
    <Link
      href={item.href}
      className={mobile ? `bottom-link${active ? " active" : ""}` : `nav-link${active ? " active" : ""}`}
      data-testid={`link-${item.label.toLowerCase().replaceAll(" ", "-")}`}
    >
      <item.icon />
      <span>{item.label}</span>
    </Link>
  );
}

function AppShell({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const { isSignedIn } = useAuth();
  const { signOut } = useClerk();
  const profileQuery = useProfileQuery(Boolean(isSignedIn));
  const meta = pageMeta[location] ?? pageMeta["/"];
  const mobileItems = [navItems[0], navItems[1], navItems[2], accountItems[0], accountItems[3]];
  const profile = profileQuery.data;
  return (
    <div className="app-shell">
      <aside className="sidebar" aria-label="Primary navigation">
        <Link href="/" className="brand" data-testid="link-brand">
          <span className="brand-mark">T</span>
          <span>
            <span className="brand-name">Trust Money</span>
            <span className="brand-tagline">Rewards, made clear</span>
          </span>
        </Link>
        <div className="nav-label">Explore</div>
        <nav className="nav-list">{navItems.map((item) => <NavItem key={item.href} item={item} />)}</nav>
        <div className="nav-label" style={{ marginTop: 30 }}>Your account</div>
        <nav className="nav-list">{accountItems.map((item) => <NavItem key={item.href} item={item} />)}</nav>
        <div className="sidebar-spacer" />
        <div className="sidebar-note">
          <ShieldCheck size={16} className="sidebar-note-icon" />
          <p>Demo credits are not money. We keep that detail visible on every screen.</p>
        </div>
        <div className="sidebar-foot">
          <div className="avatar">{initials(profile)}</div>
          <div className="sidebar-account-copy">
            <div className="sidebar-foot-name">{profile?.displayName ?? "Guest mode"}</div>
            <div className="sidebar-foot-status">{isSignedIn ? "Session active" : "Browse before signing in"}</div>
          </div>
          {isSignedIn && (
            <button className="sidebar-logout" aria-label="Sign out" onClick={() => signOut({ redirectUrl: basePath || "/" })}>
              <LogOut size={14} />
            </button>
          )}
        </div>
      </aside>
      <main className="main-area">
        <header className="topbar">
          <div>
            <div className="topbar-kicker">{meta.kicker}</div>
            <div className="topbar-title">{meta.title}</div>
          </div>
          <div className="topbar-actions">
            <div className="notification-wrap">
              <button className="icon-button" onClick={() => setNotificationsOpen((value) => !value)} aria-label="Open notifications" data-testid="button-open-notifications">
                <Bell size={17} />
                <span className="notification-dot" />
              </button>
              {notificationsOpen && (
                <div className="notification-popover" role="status" data-testid="status-notifications">
                  <strong>No unread updates</strong>
                  <p>Task, bonus, and withdrawal updates will appear here as your account activity changes.</p>
                </div>
              )}
            </div>
            {isSignedIn ? (
              <Link href="/profile" className="avatar" data-testid="link-profile-avatar">{initials(profile)}</Link>
            ) : (
              <Link href="/auth" className="button button-quiet topbar-auth-link">Sign in</Link>
            )}
          </div>
        </header>
        <div className="content">{children}</div>
      </main>
      <nav className="bottom-nav" aria-label="Mobile navigation">
        {mobileItems.map((item) => <NavItem key={item.href} item={item} mobile />)}
      </nav>
    </div>
  );
}

function PageIntro({ eyebrow, title, description, action }: { eyebrow: string; title: string; description: string; action?: ReactNode }) {
  return (
    <div className="page-intro reveal">
      <div>
        <div className="eyebrow">{eyebrow}</div>
        <h1 className="page-heading">{title}</h1>
        <p className="page-description">{description}</p>
      </div>
      {action}
    </div>
  );
}

function EmptyState({ icon: Icon, title, copy, className = "" }: { icon: typeof Info; title: string; copy: string; className?: string }) {
  return (
    <div className={`empty-panel ${className}`} data-testid="empty-state">
      <div className="empty-icon"><Icon size={19} /></div>
      <strong>{title}</strong>
      <p>{copy}</p>
    </div>
  );
}

function LoadingState() {
  return <div className="loading-state"><LoaderCircle size={20} className="spin" /><span>Loading your Trust Money data…</span></div>;
}

function ErrorState({ error }: { error: Error }) {
  return <div className="info-banner error-banner"><Info size={16} /><span>{error.message}</span></div>;
}

function AuthPrompt({ title = "Sign in to use your account" }: { title?: string }) {
  const [phoneInfo, setPhoneInfo] = useState(false);
  return (
    <section className="card auth-prompt reveal">
      <div className="stage-symbol"><ShieldCheck size={28} /></div>
      <div>
        <div className="eyebrow">Account access</div>
        <h2>{title}</h2>
        <p>Use email and password for secure access. Phone number can be saved to your profile, while SMS sign-in is not enabled in this prototype.</p>
        <div className="auth-prompt-actions">
          <Link href="/sign-in" className="button button-primary">Sign in with email</Link>
          <Link href="/sign-up" className="button button-outline">Create account</Link>
          <button className="button button-quiet" onClick={() => setPhoneInfo((value) => !value)} data-testid="button-phone-access">
            {phoneInfo ? "Hide phone note" : "Phone access"}
          </button>
        </div>
        {phoneInfo && <div className="micro-note auth-phone-note"><Info size={13} /> SMS sign-in will be added when a phone-capable auth provider is connected.</div>}
      </div>
    </section>
  );
}

function Home() {
  const { isSignedIn } = useAuth();
  const profileQuery = useProfileQuery(Boolean(isSignedIn));
  const walletQuery = useQuery<Wallet>({ queryKey: ["wallet"], queryFn: rewardsApi.getWallet, enabled: Boolean(isSignedIn) });
  const quickLinks = [
    { href: "/tasks", label: "Find a task", copy: "Browse what is available", icon: ClipboardCheck },
    { href: "/daily-bonus", label: "Daily bonus", copy: "Check today’s status", icon: Gift },
    { href: "/lucky-spin", label: "Lucky spin", copy: "Use one demo turn", icon: RotateCw },
    { href: "/referral", label: "Invite someone", copy: "View your referral code", icon: UsersRound },
  ];
  return (
    <>
      <section className="hero-card reveal">
        <div className="hero-content">
          <div className="hero-mark"><span /> A calmer way to explore rewards</div>
          <h1 className="hero-title">{isSignedIn ? "Make room for the right kind of progress." : "A clearer place to start."}</h1>
          <p className="hero-copy">Trust Money keeps tasks, demo rewards, and account activity in one place — with no promise that demo credits are real money.</p>
          <div className="hero-actions">
            <Link href={isSignedIn ? "/tasks" : "/auth"} className="button button-primary">{isSignedIn ? "Explore tasks" : "Get started"} <ArrowRight size={15} /></Link>
            <Link href={isSignedIn ? "/wallet" : "/sign-in"} className="button button-quiet">{isSignedIn ? "View wallet" : "Sign in"}</Link>
          </div>
        </div>
      </section>
      {!isSignedIn ? (
        <div className="home-public-grid reveal delay-1">
          <AuthPrompt title="Create a persistent account" />
          <section className="card surface">
            <div className="section-heading"><h2>What you can try</h2><span>Prototype scope</span></div>
            <div className="info-list">
              <div className="info-row"><ShieldCheck size={16} /><div><strong>Secure session</strong><p>Your sign-in is handled by the configured auth provider.</p></div></div>
              <div className="info-row"><TicketCheck size={16} /><div><strong>Demo rewards only</strong><p>Spin results and credits are clearly marked with no cash value.</p></div></div>
              <div className="info-row"><Clock3 size={16} /><div><strong>Pending, not paid</strong><p>Withdrawal requests are saved as demo records and never sent to a payment service.</p></div></div>
            </div>
          </section>
        </div>
      ) : (
        <>
          <div className="overview-grid reveal delay-1">
            <section className="card card-pad">
              <div className="section-heading"><h2>Your overview</h2><span>Live account snapshot</span></div>
              {profileQuery.isLoading || walletQuery.isLoading ? <LoadingState /> : profileQuery.error || walletQuery.error ? <ErrorState error={(profileQuery.error ?? walletQuery.error) as Error} /> : (
                <div className="stat-grid">
                  <div className="card stat-card"><div className="stat-label">Demo credits</div><div className="stat-value">{walletQuery.data?.demoCredits ?? 0}</div><div className="stat-note">No cash value or payment claim.</div></div>
                  <div className="card stat-card"><div className="stat-label">Account</div><div className="stat-value">Ready</div><div className="stat-note">{profileQuery.data?.email || "Email connected"}</div></div>
                  <div className="card stat-card"><div className="stat-label">Referral code</div><div className="stat-value mono">{profileQuery.data?.referralCode ?? "—"}</div><div className="stat-note">Share from the referral page.</div></div>
                </div>
              )}
            </section>
            <section className="card card-pad activity-card">
              <div className="section-heading"><h2>Recent activity</h2><Link href="/transactions" className="link-arrow">See history <ChevronRight size={13} /></Link></div>
              <div className="activity-empty"><Clock3 size={19} /><span>Every demo credit and pending request will be easy to review.</span></div>
              <div className="status-line" style={{ marginTop: 19 }}>Persistent account connected</div>
            </section>
          </div>
          <section className="quick-grid reveal delay-2">
            {quickLinks.map((item) => <Link href={item.href} className="quick-link" key={item.href}><item.icon /><span>{item.label}</span><small>{item.copy}</small></Link>)}
          </section>
        </>
      )}
    </>
  );
}

function Tasks() {
  const [filter, setFilter] = useState("All tasks");
  const [search, setSearch] = useState("");
  const queryClient = useQueryClient();
  const tasksQuery = useQuery<Task[]>({ queryKey: ["tasks"], queryFn: rewardsApi.getTasks });
  const completeMutation = useMutation({
    mutationFn: rewardsApi.completeTask,
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["tasks"] }),
  });
  const filters = ["All tasks", "Surveys", "Offers", "Profile"];
  const tasks = useMemo(() => (Array.isArray(tasksQuery.data) ? tasksQuery.data : []).filter((task) => task != null).filter((task) =>
    (filter === "All tasks" || task.category === filter.slice(0, -1) || task.category === filter) &&
    `${task.title} ${task.description}`.toLowerCase().includes(search.toLowerCase()),
  ), [filter, search, tasksQuery.data]);
  return (
    <>
      <PageIntro eyebrow="A considered starting point" title="Choose what fits." description="Complete demo tasks to test the flow. Every card explains that it has no cash value." action={<button className="button button-outline" disabled><LayoutGrid size={14} /> Curated list</button>} />
      <div className="two-col">
        <section className="card surface reveal delay-1">
          <div className="filter-row">
            <div className="search-box"><Search size={15} /><input className="search-input" value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search tasks" aria-label="Search tasks" /></div>
            {filters.map((item) => <button key={item} className={`filter-button${filter === item ? " active" : ""}`} onClick={() => setFilter(item)}>{item}</button>)}
          </div>
          {tasksQuery.isLoading ? <LoadingState /> : tasksQuery.error ? <ErrorState error={tasksQuery.error as Error} /> : tasks.length > 0 ? (
            <div className="task-list">{tasks.map((task) => (
              <div className={`task-row${task.completed ? " completed" : ""}`} key={task.id}>
                <div className="task-main"><div className="task-icon">{task.completed ? <Check size={17} /> : <CircleHelp size={17} />}</div><div><div className="task-title">{task.title}</div><div className="task-meta"><span>{task.category}</span><span>{task.duration}</span><span>Demo only</span></div><p className="task-description">{task.description}</p></div></div>
                <div className="task-action"><span className="task-reward">{task.completed ? "Completed" : "No cash value"}</span><button className={`button ${task.completed ? "button-quiet" : "button-outline"}`} disabled={task.completed || completeMutation.isPending} onClick={() => completeMutation.mutate(task.id)}>{completeMutation.isPending && !task.completed ? <LoaderCircle size={13} className="spin" /> : task.completed ? "Done" : "Mark complete"}</button></div>
              </div>
            ))}</div>
          ) : <EmptyState icon={Search} title="No tasks match that search" copy="Try a different phrase or return to all tasks." />}
          <div className="task-note" style={{ marginTop: 16 }}><Info size={14} /> These task cards are demo records. Completing one does not add money or payment value.</div>
        </section>
        <aside className="feature-visual reveal delay-2">
          <div className="visual-orbit" />
          <div className="visual-copy"><small>Task guide / 01</small><h2>Clear before you commit.</h2><p>You’ll always see the estimated time, task type, and demo status before anything begins.</p></div>
          <div className="detail-steps"><div className="detail-step"><div className="step-number">1</div><div><strong>Read the brief</strong><p>Understand what is expected.</p></div></div><div className="detail-step"><div className="step-number">2</div><div><strong>Mark the demo complete</strong><p>Test the persistence flow.</p></div></div></div>
        </aside>
      </div>
    </>
  );
}

function Bonus() {
  const queryClient = useQueryClient();
  const query = useQuery<DailyBonus>({ queryKey: ["daily-bonus"], queryFn: rewardsApi.getDailyBonus });
  const mutation = useMutation({ mutationFn: rewardsApi.claimDailyBonus, onSuccess: () => queryClient.invalidateQueries({ queryKey: ["daily-bonus"] }) });
  return (
    <>
      <PageIntro eyebrow="A daily pause" title="Check in when it feels right." description="The once-per-day state is persisted to your account. Claiming is a demo check-in only and adds no cash value." />
      <section className="card center-stage reveal delay-1"><div><div className="stage-symbol"><Gift size={32} /></div><h2 className="stage-title">{query.data?.claimed ? "Today’s check-in is recorded" : "Your daily check-in is ready"}</h2><p className="stage-copy">{query.data?.message ?? "Loading today’s status…"}</p><button className="button button-primary" disabled={query.isLoading || Boolean(query.data?.claimed) || mutation.isPending} onClick={() => mutation.mutate()}>{mutation.isPending ? "Recording…" : query.data?.claimed ? "Claimed for today" : "Claim daily check-in"}</button><div className="micro-note" style={{ marginTop: 15 }}><LockKeyhole size={13} /> Once per day • demo only</div></div></section>
      <div className="two-col reveal delay-2" style={{ marginTop: 18 }}><section className="card surface"><div className="section-heading"><h2>How it works</h2><span>Simple by design</span></div><div className="detail-steps"><div className="detail-step"><div className="step-number">1</div><div><strong>Check in once a day</strong><p>Your account keeps the claim date so refreshes do not reset it.</p></div></div><div className="detail-step"><div className="step-number">2</div><div><strong>Review the details</strong><p>The screen always says whether anything of value was added.</p></div></div></div></section><div className="info-banner"><Info size={16} /><span>Demo check-ins are stored for testing and have no cash value.</span></div></div>
    </>
  );
}

function Spin() {
  const queryClient = useQueryClient();
  const query = useQuery<LuckySpinStatus>({ queryKey: ["lucky-spin"], queryFn: rewardsApi.getLuckySpin });
  const [result, setResult] = useState<SpinResult | null>(null);
  const mutation = useMutation({ mutationFn: rewardsApi.spinLuckyWheel, onSuccess: (value) => { setResult(value); queryClient.invalidateQueries({ queryKey: ["lucky-spin"] }); queryClient.invalidateQueries({ queryKey: ["wallet"] }); queryClient.invalidateQueries({ queryKey: ["transactions"] }); } });
  return (
    <>
      <PageIntro eyebrow="A little variety" title="Know the rules before the spin." description="You get one server-checked demo turn per day. Any result is a demo credit with no cash value and no payment promise." />
      <section className="card center-stage reveal delay-1"><div><div className={`stage-symbol${mutation.isPending ? " spinning" : ""}`}><RotateCw size={32} /></div><h2 className="stage-title">{result ? result.label : query.data?.available ? "Your demo spin is ready" : "Come back tomorrow"}</h2><p className="stage-copy">{result ? `${result.demoCredits} demo credits were recorded. They are not money and cannot be paid out.` : query.data?.available ? "The result is chosen on the server and saved to your account for one clear test flow." : "The once-per-day demo turn has already been used for this account."}</p><button className="button button-primary" disabled={query.isLoading || !query.data?.available || mutation.isPending} onClick={() => mutation.mutate()}>{mutation.isPending ? "Spinning…" : result ? "Result recorded" : "Spin demo wheel"}</button><div className="micro-note" style={{ marginTop: 15 }}><LockKeyhole size={13} /> Safe demo reward • no cash value</div></div></section>
      <section className="card surface reveal delay-2" style={{ marginTop: 18 }}><div className="section-heading"><h2>Our promise</h2><BadgeCheck size={17} color="hsl(var(--primary))" /></div><div className="info-list"><div className="info-row"><ShieldCheck size={16} /><div><strong>Details first</strong><p>Eligibility, timing, and outcomes are visible before the button.</p></div></div><div className="info-row"><TicketCheck size={16} /><div><strong>Optional by nature</strong><p>Skipping a spin never blocks the rest of Trust Money.</p></div></div></div></section>
    </>
  );
}

function Referral() {
  const query = useQuery<Referral>({ queryKey: ["referral"], queryFn: rewardsApi.getReferral });
  const [copied, setCopied] = useState(false);
  const handleCopy = async () => {
    if (!query.data) return;
    await navigator.clipboard?.writeText(query.data.link);
    setCopied(true);
    window.setTimeout(() => setCopied(false), 2200);
  };
  return (
    <>
      <PageIntro eyebrow="Share with care" title="Invite people you trust." description="Your referral code is persistent and unique to your account. Referral rewards are not active in this demo." />
      <div className="referral-grid">
        <section className="referral-card reveal delay-1">
          <div className="eyebrow">Your referral code</div>
          <h2>{query.data?.code ?? "Loading your code…"}</h2>
          <p>Share the code or link with context. No referral payout is calculated in this prototype.</p>
          <div className="referral-link-box"><input className="referral-input" value={query.data?.link ?? ""} readOnly aria-label="Referral link" /><button className="button button-primary" disabled={!query.data} onClick={handleCopy}><Copy size={14} /> {copied ? "Copied" : "Copy link"}</button></div>
        </section>
        <section className="card surface reveal delay-2"><div className="section-heading"><h2>Before you share</h2><span>Good to know</span></div><div className="info-list"><div className="info-row"><UsersRound size={16} /><div><strong>Share with context</strong><p>Tell someone what Trust Money is and what they can expect.</p></div></div><div className="info-row"><Info size={16} /><div><strong>Terms stay visible</strong><p>Any referral conditions will be shown before an invite is sent.</p></div></div><div className="info-row"><ShieldCheck size={16} /><div><strong>No payout yet</strong><p>Referred count and rewards are stored as demo data only.</p></div></div></div></section>
      </div>
    </>
  );
}

function Wallet() {
  const query = useQuery<Wallet>({ queryKey: ["wallet"], queryFn: rewardsApi.getWallet });
  return (
    <>
      <PageIntro eyebrow="A transparent view" title="Your wallet, without guesswork." description="This wallet stores demo credits for testing the experience. They have no cash value and are not a payment balance." action={<Link href="/withdrawal" className="button button-outline">Withdrawal <ArrowRight size={14} /></Link>} />
      <div className="wallet-layout">
        <section className="wallet-card reveal delay-1"><div className="eyebrow">Demo credits</div><h2>{query.isLoading ? "…" : query.data?.demoCredits ?? 0}</h2><p>No cash value • no payment claim</p><div className="wallet-line"><span>TRUST MONEY DEMO</span><span>NOT MONEY</span></div></section>
        <section className="card surface reveal delay-2"><div className="section-heading"><h2>Wallet status</h2><span>Persistent account</span></div><div className="info-banner"><ShieldCheck size={16} /><span>Any demo credits are stored for this signed-in account and are never presented as real earnings.</span></div><div className="detail-steps"><div className="detail-step"><div className="step-number"><Check size={13} /></div><div><strong>Wallet screen ready</strong><p>Your balance is read from the database.</p></div></div><div className="detail-step"><div className="step-number">2</div><div><strong>Payment connection later</strong><p>Withdrawal remains demo-only until a payment system is connected.</p></div></div></div></section>
      </div>
      <section className="card surface reveal delay-3" style={{ marginTop: 18 }}><div className="section-heading"><h2>Next step</h2><Link href="/transactions" className="link-arrow">View transactions <ChevronRight size={13} /></Link></div><EmptyState icon={History} title="Review your activity" copy="Spin results, check-ins, and pending demo withdrawal requests will appear in your transaction history." /></section>
    </>
  );
}

function Transactions() {
  const query = useQuery<Transaction[]>({ queryKey: ["transactions"], queryFn: rewardsApi.getTransactions });
  return (
    <>
      <PageIntro eyebrow="A readable record" title="Nothing hidden in the history." description="These records are for demo activity only. A zero value means the action was recorded without adding any credits." />
      <section className="card surface transaction-panel reveal delay-1">
        <div className="section-heading"><h2>Account activity</h2><span>{query.data?.length ?? 0} records</span></div>
        {query.isLoading ? <LoadingState /> : query.error ? <ErrorState error={query.error as Error} /> : Array.isArray(query.data) && query.data.filter(Boolean).length > 0 ? <div className="transaction-list">{query.data.filter(Boolean).map((item) => <div className="transaction-row" key={item.id}><div className="transaction-icon"><History size={15} /></div><div className="transaction-copy"><strong>{item.label || "Activity record"}</strong><span>{formatActivityDate(item.createdAt)} • {formatTransactionStatus(item.status)}</span></div><div className="transaction-amount">{item.demoCredits > 0 ? `+${item.demoCredits}` : "0"}<small>demo credits</small></div></div>)}</div> : <EmptyState icon={History} title="Your transaction history is empty" copy="Complete a demo action and its record will appear here. There are no cash amounts to show." />}
        <div className="task-note" style={{ marginTop: 16 }}><Info size={14} /> Transaction records do not represent payments, earnings, or settled withdrawals.</div>
      </section>
    </>
  );
}

function Withdrawal() {
  const walletQuery = useQuery<Wallet>({ queryKey: ["wallet"], queryFn: rewardsApi.getWallet });
  const query = useQuery<Withdrawal[]>({ queryKey: ["withdrawals"], queryFn: rewardsApi.getWithdrawals });
  const queryClient = useQueryClient();
  const [method, setMethod] = useState("Demo wallet");
  const [accountNumber, setAccountNumber] = useState("");
  const [amountCredits, setAmountCredits] = useState("");
  const [message, setMessage] = useState("");
  const [withdrawalRequestKey, setWithdrawalRequestKey] = useState(() => crypto.randomUUID());
  const mutation = useMutation({
    mutationFn: (data: WithdrawalInput) => rewardsApi.createWithdrawal(data, withdrawalRequestKey),
    onSuccess: () => {
      setMessage("Pending demo request saved. No payment was sent.");
      setAccountNumber("");
      setAmountCredits("");
      setWithdrawalRequestKey(crypto.randomUUID());
      queryClient.invalidateQueries({ queryKey: ["withdrawals"] });
      queryClient.invalidateQueries({ queryKey: ["transactions"] });
    },
    onError: (error: Error) => setMessage(error.message),
  });
  return (
    <>
      <PageIntro eyebrow="Move with confidence" title="Withdrawal, when you’re ready." description="You can test the request flow, but every request is explicitly pending demo and never sent to a payment service." />
      <section className="card surface reveal delay-1"><div className="section-heading"><h2>Request a withdrawal</h2><span>Demo only</span></div><div className="info-banner"><ShieldCheck size={16} /><span>Demo credits are not real money. This form creates a pending test record and does not deduct or transfer anything.</span></div><div className="form-stack withdrawal-form"><div className="form-field"><label htmlFor="withdrawal-method">Method</label><select id="withdrawal-method" value={method} onChange={(event) => setMethod(event.target.value)}><option>Demo wallet</option><option>Bank transfer (demo)</option><option>Mobile wallet (demo)</option></select></div><div className="form-field"><label htmlFor="withdrawal-account">Account number or handle</label><input id="withdrawal-account" value={accountNumber} onChange={(event) => setAccountNumber(event.target.value)} placeholder="Enter a test destination" /></div><div className="form-field"><label htmlFor="withdrawal-amount">Amount in demo credits</label><input id="withdrawal-amount" inputMode="numeric" type="number" min="1" value={amountCredits} onChange={(event) => setAmountCredits(event.target.value)} placeholder={`Available demo credits: ${walletQuery.data?.demoCredits ?? 0}`} /><span className="form-helper">This is not a currency amount. No payment will be made.</span></div><button className="button button-primary" disabled={mutation.isPending || !accountNumber || !amountCredits} onClick={() => mutation.mutate({ method, accountNumber, amountCredits: Number(amountCredits) })}>{mutation.isPending ? "Saving request…" : "Save pending demo request"}</button>{message && <div className="status-line">{message}</div>}</div></section>
      <div className="two-col reveal delay-2" style={{ marginTop: 18 }}><section className="card surface"><div className="section-heading"><h2>Pending requests</h2><span>Never paid</span></div>{query.isLoading ? <LoadingState /> : query.error ? <ErrorState error={query.error as Error} /> : Array.isArray(query.data) && query.data.filter(Boolean).length > 0 ? <div className="withdrawal-list">{query.data.filter(Boolean).map((item) => <div className="withdrawal-row" key={item.id}><div><strong>{item.method || "Demo withdrawal"}</strong><span>{item.accountNumber || "Account not provided"} • {item.amountCredits ?? 0} demo credits</span></div><span className="pending-badge">Pending demo</span></div>)}</div> : <EmptyState icon={Clock3} title="No withdrawal requests" copy="Your test requests will appear here with their pending status." />}</section><div className="info-banner"><Clock3 size={16} /><span>Real payout timing and settlement will only exist after a payment provider is connected.</span></div></div>
    </>
  );
}

function Profile() {
  const { user } = useUser();
  const profileQuery = useProfileQuery(true);
  const queryClient = useQueryClient();
  const { signOut } = useClerk();
  const [editing, setEditing] = useState(false);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [saved, setSaved] = useState("");
  const [notifications, setNotifications] = useState(false);
  useEffect(() => {
    if (profileQuery.data) {
      setName(profileQuery.data.displayName);
      setPhone(profileQuery.data.phone ?? "");
    }
  }, [profileQuery.data]);
  const mutation = useMutation({
    mutationFn: rewardsApi.updateMe,
    onSuccess: () => {
      setSaved("Profile saved to your account.");
      setEditing(false);
      queryClient.invalidateQueries({ queryKey: ["me"] });
    },
    onError: (error: Error) => setSaved(error.message),
  });
  const profile = profileQuery.data;
  return (
    <>
      <PageIntro eyebrow="Account / Profile" title="A profile that stays yours." description="Your display name and optional phone number are stored with your account. Phone sign-in is not enabled yet." action={<button className="button button-primary" onClick={() => setEditing((value) => !value)}><Pencil size={14} /> {editing ? "Close editor" : "Edit profile"}</button>} />
      <div className="profile-layout">
        <section className="card profile-card reveal delay-1"><div className="profile-avatar">{initials(profile)}</div><h2>{profile?.displayName ?? "Trust Money member"}</h2><p>{profile?.email || user?.primaryEmailAddress?.emailAddress || "Email connected"}</p><div className="security-line"><ShieldCheck size={12} /> Session protected</div><button className="button button-quiet profile-logout" onClick={() => signOut({ redirectUrl: basePath || "/" })}><LogOut size={14} /> Sign out</button></section>
        <section className="card surface reveal delay-2">
          {editing ? <div className="form-stack"><div className="form-field"><label htmlFor="profile-name">Display name</label><input id="profile-name" value={name} onChange={(event) => setName(event.target.value)} placeholder="Your name" /></div><div className="form-field"><label htmlFor="profile-phone">Phone number (optional)</label><input id="profile-phone" type="tel" value={phone} onChange={(event) => setPhone(event.target.value)} placeholder="+880…" /><span className="form-helper">Saved as profile data only. SMS sign-in is not enabled.</span></div><button className="button button-primary" disabled={mutation.isPending} onClick={() => mutation.mutate({ displayName: name, phone })}><Check size={14} /> {mutation.isPending ? "Saving…" : "Save profile"}</button>{saved && <div className="status-line">{saved}</div>}</div> : <div className="settings-list"><div className="settings-row"><div><strong>Display name</strong><span>{profile?.displayName ?? "Not added yet"}</span></div><button className="button button-quiet" onClick={() => setEditing(true)}>Change</button></div><div className="settings-row"><div><strong>Email</strong><span>{profile?.email || user?.primaryEmailAddress?.emailAddress || "Connected through auth"}</span></div><BadgeCheck size={16} color="hsl(var(--primary))" /></div><div className="settings-row"><div><strong>Activity updates</strong><span>Get a gentle note when something changes.</span></div><button className={`toggle${notifications ? " active" : ""}`} onClick={() => setNotifications((value) => !value)} aria-label="Toggle activity updates" aria-pressed={notifications}><span className="toggle-thumb" /></button></div><div className="settings-row"><div><strong>Help and transparency</strong><span>Review how demo credits and requests work.</span></div><Link href="/transactions" className="link-arrow">Review <ChevronRight size={13} /></Link></div></div>}
        </section>
      </div>
      <section className="card surface reveal delay-3" style={{ marginTop: 18 }}><div className="section-heading"><h2>Need a hand?</h2><span>We’re here to clarify</span></div><div className="info-banner"><LifeBuoy size={16} /><span>Your session is persistent through the auth provider. Sign out here whenever you are finished testing.</span></div></section>
    </>
  );
}

function ProtectedRoute({ Component }: { Component: () => ReactElement }) {
  const { isLoaded, isSignedIn } = useAuth();
  if (!isLoaded) return <LoadingState />;
  if (!isSignedIn) return <AuthPrompt />;
  return <Component />;
}

function AuthHub() {
  return (
    <div className="auth-hub">
      <div className="auth-hub-mark"><span className="brand-mark">T</span><span className="brand-name">Trust Money</span></div>
      <div className="auth-hub-copy"><div className="eyebrow">Account access</div><h1>Keep your progress connected.</h1><p>Sign in with email and password to persist your profile, task states, demo rewards, and pending requests.</p></div>
      <div className="auth-hub-actions"><Link href="/sign-in" className="button button-primary">Sign in with email <ArrowRight size={15} /></Link><Link href="/sign-up" className="button button-outline">Create an account</Link></div>
      <div className="auth-hub-note"><Info size={15} /><span>Phone numbers can be stored on your profile. SMS sign-in is not enabled in this prototype.</span></div>
    </div>
  );
}

function SignInPage() {
  return <div className="auth-page"><SignIn routing="path" path={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} /></div>;
}

function SignUpPage() {
  return <div className="auth-page"><SignUp routing="path" path={`${basePath}/sign-up`} signInUrl={`${basePath}/sign-in`} /></div>;
}

function ClerkQueryClientCacheInvalidator() {
  const { addListener } = useClerk();
  const client = useQueryClient();
  const previousUserId = useRef<string | null | undefined>(undefined);
  useEffect(() => {
    const unsubscribe = addListener(({ user }) => {
      const nextUserId = user?.id ?? null;
      if (previousUserId.current !== undefined && previousUserId.current !== nextUserId) client.clear();
      previousUserId.current = nextUserId;
    });
    return unsubscribe;
  }, [addListener, client]);
  return null;
}

function Router() {
  const [location] = useLocation();
  return (
    <AppShell>
      <ErrorBoundary resetKey={location}>
        <Switch>
          <Route path="/" component={Home} />
          <Route path="/auth" component={AuthHub} />
          <Route path="/sign-in/*?" component={SignInPage} />
          <Route path="/sign-up/*?" component={SignUpPage} />
          <Route path="/tasks" component={() => <ProtectedRoute Component={Tasks} />} />
          <Route path="/daily-bonus" component={() => <ProtectedRoute Component={Bonus} />} />
          <Route path="/lucky-spin" component={() => <ProtectedRoute Component={Spin} />} />
          <Route path="/referral" component={() => <ProtectedRoute Component={Referral} />} />
          <Route path="/wallet" component={() => <ProtectedRoute Component={Wallet} />} />
          <Route path="/withdrawal" component={() => <ProtectedRoute Component={Withdrawal} />} />
          <Route path="/transactions" component={() => <ProtectedRoute Component={Transactions} />} />
          <Route path="/profile" component={() => <ProtectedRoute Component={Profile} />} />
          <Route component={NotFound} />
        </Switch>
      </ErrorBoundary>
    </AppShell>
  );
}

function ClerkProviderWithRoutes() {
  const [, setLocation] = useLocation();
  if (!clerkPubKey) throw new Error("Missing VITE_CLERK_PUBLISHABLE_KEY in environment.");
  return (
    <ClerkProvider
      publishableKey={clerkPubKey}
      proxyUrl={clerkProxyUrl}
      appearance={appearance}
      signInUrl={`${basePath}/sign-in`}
      signUpUrl={`${basePath}/sign-up`}
      localization={{
        signIn: { start: { title: "Welcome back", subtitle: "Sign in to access Trust Money" } },
        signUp: { start: { title: "Create your account", subtitle: "Keep your Trust Money activity connected" } },
      }}
      routerPush={(to) => setLocation(stripBase(to))}
      routerReplace={(to) => setLocation(stripBase(to), { replace: true })}
    >
      <QueryClientProvider client={queryClient}>
        <ClerkQueryClientCacheInvalidator />
        <Router />
      </QueryClientProvider>
    </ClerkProvider>
  );
}

function App() {
  return (
    <WouterRouter base={basePath}>
      <ClerkProviderWithRoutes />
      <Toaster />
    </WouterRouter>
  );
}

export default function RootApp() {
  return <App />;
}