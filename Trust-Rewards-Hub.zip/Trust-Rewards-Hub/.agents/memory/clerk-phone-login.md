---
name: Clerk phone login
description: Authentication capability boundary for Trust Money and similar apps using Replit-managed Clerk.
---

Replit-managed Clerk supports email/password authentication but does not currently support SMS/phone sign-in. Phone numbers can still be collected as optional profile data without presenting phone login as functional.

**Why:** The product request asked for phone/email access, but implementing a local phone-auth system would bypass the managed authentication path and create an unsafe parallel session system.

**How to apply:** Keep email/password as the real sign-in path, label phone access as unavailable until a phone-capable provider is connected, and avoid implying that a phone number alone creates a session.