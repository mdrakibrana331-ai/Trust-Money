---
name: Rewards data nullability
description: Defensive handling rules for Trust Money reward, transaction, and profile data.
---

Treat API and database reward records as nullable at the UI boundary even when the schema marks fields as required. In particular, transaction status/date, profile phone, and signed-out Clerk auth state must have safe fallbacks before rendering or calling string/date methods.

**Why:** Existing or partially initialized development data can violate the ideal schema shape, and the UI should remain usable while the API reports an error or an empty result.

**How to apply:** Normalize arrays before mapping, guard string methods such as `replaceAll`, format dates through a checked helper, default optional profile fields to empty strings, and return a clean unauthorized response when there is no Clerk user.