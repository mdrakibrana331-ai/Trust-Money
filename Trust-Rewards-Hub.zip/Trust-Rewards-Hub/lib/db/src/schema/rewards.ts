import { createInsertSchema } from "drizzle-zod";
import {
  boolean,
  date,
  integer,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";
import { z } from "zod/v4";

export const usersTable = pgTable(
  "trust_money_users",
  {
    id: serial("id").primaryKey(),
    clerkUserId: text("clerk_user_id").notNull(),
    displayName: text("display_name").notNull().default("Trust Money member"),
    email: text("email").notNull().default(""),
    phone: text("phone").notNull().default(""),
    referralCode: text("referral_code").notNull(),
    demoCredits: integer("demo_credits").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
  },
  (table) => ({
    clerkUserIdUnique: uniqueIndex("trust_money_users_clerk_user_id_idx").on(table.clerkUserId),
    referralCodeUnique: uniqueIndex("trust_money_users_referral_code_idx").on(table.referralCode),
  }),
);

export const tasksTable = pgTable(
  "trust_money_tasks",
  {
    id: serial("id").primaryKey(),
    title: text("title").notNull(),
    category: text("category").notNull(),
    description: text("description").notNull(),
    duration: text("duration").notNull(),
    demoOnly: boolean("demo_only").notNull().default(true),
    active: boolean("active").notNull().default(true),
  },
  (table) => ({
    titleUnique: uniqueIndex("trust_money_tasks_title_idx").on(table.title),
  }),
);

export const taskCompletionsTable = pgTable(
  "trust_money_task_completions",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id").notNull(),
    taskId: integer("task_id").notNull(),
    status: text("status").notNull().default("completed"),
    completedAt: timestamp("completed_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({
    userTaskUnique: uniqueIndex("trust_money_task_completion_user_task_idx").on(table.userId, table.taskId),
  }),
);

export const dailyBonusClaimsTable = pgTable(
  "trust_money_daily_bonus_claims",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id").notNull(),
    claimDate: date("claim_date", { mode: "string" }).notNull(),
    demoOnly: boolean("demo_only").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({
    userDateUnique: uniqueIndex("trust_money_daily_bonus_user_date_idx").on(table.userId, table.claimDate),
  }),
);

export const spinResultsTable = pgTable("trust_money_spin_results", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  spinDate: date("spin_date", { mode: "string" }),
  label: text("label").notNull(),
  demoCredits: integer("demo_credits").notNull(),
  demoOnly: boolean("demo_only").notNull().default(true),
  spunAt: timestamp("spun_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => ({
  userSpinDateUnique: uniqueIndex("trust_money_spin_user_date_idx").on(table.userId, table.spinDate),
}));

export const transactionsTable = pgTable("trust_money_transactions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  kind: text("kind").notNull(),
  label: text("label").notNull(),
  demoCredits: integer("demo_credits").notNull().default(0),
  status: text("status").notNull(),
  demoOnly: boolean("demo_only").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const withdrawalsTable = pgTable("trust_money_withdrawals", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  idempotencyKey: text("idempotency_key"),
  method: text("method").notNull(),
  accountNumber: text("account_number").notNull(),
  amountCredits: integer("amount_credits").notNull(),
  status: text("status").notNull().default("pending_demo"),
  demoOnly: boolean("demo_only").notNull().default(true),
  note: text("note").notNull().default("Demo request only — no payment was sent."),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertUserSchema = createInsertSchema(usersTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof usersTable.$inferSelect;
export type Task = typeof tasksTable.$inferSelect;
export type TaskCompletion = typeof taskCompletionsTable.$inferSelect;
export type DailyBonusClaim = typeof dailyBonusClaimsTable.$inferSelect;
export type SpinResult = typeof spinResultsTable.$inferSelect;
export type Transaction = typeof transactionsTable.$inferSelect;
export type Withdrawal = typeof withdrawalsTable.$inferSelect;